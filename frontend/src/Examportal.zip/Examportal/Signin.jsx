import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
// import "./Style.css";

const Signin = () => {
  const nav = useNavigate();
  const [isSignInForm, setIsSignInForm] = useState(true);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleToggleForm = () => {
    setIsSignInForm(!isSignInForm);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isSignInForm) {
        const response = await axios.post("http://localhost:8080/", {
          username: formData.username,
          password: formData.password,
        });

        if (response.data.role === "user") {
          window.localStorage.setItem("full", JSON.stringify(response.data));
          window.localStorage.setItem("id", response.data.userId);
          window.localStorage.setItem("role", response.data.role);
          window.localStorage.setItem("name", response.data.username);
          nav("/home");
        } else if (response.data.role === "admin") {
          window.localStorage.setItem("full", JSON.stringify(response.data));
          window.localStorage.setItem("id", response.data.userId);
          window.localStorage.setItem("role", response.data.role);
          window.localStorage.setItem("name", response.data.username);
          nav("/admin");
        } else {
          alert("Invalid credentials");
          setFormData({
            username: "",
            password: "",
          });
        }
      } else {
        const response = await axios.post("http://localhost:8080/adduser", {
          username: formData.username,
          email: formData.email,
          role: "user",
          password: formData.password,
          confirmPassword: formData.confirmPassword,
        });

        console.log(response.data); // Handle response as needed
      }
      // alert("Invalid credentials");
      // setFormData({
      //   password: "", // Clear password field
      //   confirmPassword: "", // Clear confirmPassword field
      // });
    } catch (error) {
      console.error("Error submitting form:", error.response?.data || error.message);
    }
  };

  return (
    <>
     <div className={`container ${isSignInForm ? "signinForm" : ""}`}>
        <form onSubmit={handleSubmit}>
          {isSignInForm ? (
            <div className="form signin">
              <h2>Sign In</h2>
              <div className="inputBox">
                <input
                  type="text"
                  required="required"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                />
                <i className="fa-regular fa-user"></i>
                <span>username</span>
              </div>
              <div className="inputBox">
                <input
                  type="password"
                  required="required"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                />
                <i className="fa-solid fa-lock"></i>
                <span>password</span>
              </div>
            </div>
          ) : (
            <div className="form signup">
              <h2>Sign Up</h2>
              <div className="inputBox">
                <input
                  type="text"
                  required="required"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                />
                <i className="fa-regular fa-user"></i>
                <span>username</span>
              </div>
              <div className="inputBox">
                <input
                  type="text"
                  required="required"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
                <i className="fa-regular fa-envelope"></i>
                <span>email address</span>
              </div>
              <div className="inputBox">
                <input
                  type="password"
                  required="required"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                />
                <i className="fa-solid fa-lock"></i>
                <span>create password</span>
              </div>
              <div className="inputBox">
                <input
                  type="password"
                  required="required"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                />
                <i className="fa-solid fa-lock"></i>
                <span>confirm password</span>
              </div>
            </div>
          )}
          <div className="inputBox">
          <button type="submit">
              {isSignInForm ? "Login" : "Create Account"}
              </button>
          </div>
        </form>

        <p>
          {isSignInForm ? (
            <>
              Not Registered ?{" "}
              <button
                type="button"
                onClick={handleToggleForm}
                className="create"
              >
                Create an account
              </button>
            </>
          ) : (
            <>
              Already a member ?{" "}
              <button
                type="button"
                onClick={handleToggleForm}
                className="login"
              >
                Log in
              </button>
            </>
          )}
        </p>
      </div>
    </>
  );
};

export default Signin;
