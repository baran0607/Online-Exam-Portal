import React, { useState, useEffect } from 'react';

const CountdownTimer = () => {
  const [seconds, setSeconds] = useState(1200); // 20 minutes in seconds
  const [timerColor, setTimerColor] = useState('black');

  useEffect(() => {
    const intervalId = setInterval(() => {
      setSeconds(prevSeconds => {
        if (prevSeconds <= 0) {
          clearInterval(intervalId);
          // Trigger alert when timer reaches 0
          alert('Warning ⚠️ ⚠️ Your exam as finish !!');
        } else if (prevSeconds <= 60) {
          // Change color to red when timer reaches 1 minute
          setTimerColor('red');
        } else if (prevSeconds === 120) {
          // Trigger alert when timer reaches 2 minutes
          alert('Alert ⚠️ ⚠️ You have 2 minutes remaining!');
        }

        return prevSeconds - 1;
      });
    }, 1000);

    // Cleanup the interval when the component unmounts
    return () => clearInterval(intervalId);
  }, []); // Empty dependency array ensures that the effect runs only once on mount

  const formatTime = (timeInSeconds) => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = timeInSeconds % 60;
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  return (
    <div style={styles.container}>
      <p style={{ fontSize: '20px', fontWeight: 'bold', color: timerColor }}>
        {formatTime(seconds)}
      </p>
    </div>
  );
};

const styles = {
  container: {
    textAlign: 'center',
    marginTop: '50px',
  },
};

export default CountdownTimer;