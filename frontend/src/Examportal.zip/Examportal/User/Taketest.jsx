import React, { useState, useEffect } from "react";
import { Modal, Alert } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import CountdownTimer from "./CountdownTimer";
import Question from "./Question";
import axios from "axios";


const Taketest = () => {
  const nav = useNavigate();
  const [q, setq] = useState([]);
  const [f, setf] = useState(0);
  const [showOptions, setShowOptions] = useState(false);
  const location=useLocation();
  const [questions,setquestions]=useState();
  const{state}=location;
  const[qpid,setqpid]=useState("");
  const handleButtonClick = (id) => {
    setf(id - 1);
    setShowOptions(false);
  };
  useEffect(() => {

    axios.post("http://localhost:8080/getqp",{examid:state.examid}).then((res)=>{console.log(res.data);
    var l=[];
    setqpid(res.data[0].qp.qpid)
    for(var i=0;i<res.data.length;i++)
    {
      console.log(res.data[i].q);
      l.push(res.data[i].q);
    }
    var i = 1;
    const x = l.map((k) => {
      k.id = i++;
      k.selected = "";
      k.bookmark = false;
      k.mark = 0;
      return k;
    });
    setq(x);})
  }, []);

  const selectanswer = (id, ans) => {
    const x = q.map((k) => {
      if (k.id === id) {
        console.log(k);
        k.selected = ans;
        axios.post("http://localhost:8080/selectanswer",{userans:ans,q:{qid:k.qid},qp:{qpid:qpid}}).then((res)=>{console.log(res.data)})
      }
      return k;
    });
    setq(x);
  };

  const bookmarkfun = (i) => {
    const x = q.map((k) => {
      if (k.id === i) {
        k.bookmark = !k.bookmark;
      }
      return k;
    });
    setq(x);
  };

  const [totalMarks, setTotalMarks] = useState(0);

  const calculateMarks = () => {
    let marks = 0;
    q.forEach((question) => {
      if (question.selected === question.rightans) {
        marks += 1;
      }
    });
    setTotalMarks(marks);
    console.log(marks);
  };
  

return (
  <div className="container" style={{ backgroundColor: "yellow" }}>
    <div
      style={{
        marginLeft: "90%",
        backgroundColor: "red",
      }}
    >
      <CountdownTimer />
    </div>
    {q.length !== 0 && (
      <>
        <Question
          r={q[f]}
          selectanswer={selectanswer}
          bookmarkfun={bookmarkfun}
        />
        
        <div
          style={{
            justifyContent: "space-between",
            marginBottom: "55%",
            padding: 20,
          }}
        >
          {f === 0 ? (
         
            <button disabled>previous</button>
          ) : (

            <button
              onClick={() => {
                if (f > 0) {
                  setf(f - 1);
                }
              }}
            >
              previous
            </button>
          )}
         
          <button
            onClick={() => {
              if (f < q.length - 1) {
                setf(f + 1);
              } else {
              }
            }}
          >
            next
          </button>
          <button
            onClick={() => {
              alert("Warning ⚠️ ⚠️", "Do you want to submit !!!")
            }}
          >
            submit
          </button>
          <div style={{display:"flex"}} >
                {q.map((r) => (
                  <button
                    style={{
                      backgroundColor: r.bookmark
                        ? "red"
                        : r.selected.length !== 0
                        ? "green"
                        : "transparent",
                    }}
                    onClick={() => handleButtonClick(r.id)}
                  >
                    {String(r.id)}
                  </button>
                ))}
              </div>
              
        </div>
      </>
    )}
  </div>
);
};

export default Taketest;