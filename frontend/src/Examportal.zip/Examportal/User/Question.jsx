import React from "react";
import { FaRegBookmark } from "react-icons/fa";
import { FaBookmark } from "react-icons/fa";

const Question = ({ r, selectanswer, bookmarkfun }) => {
  return (
    <div >
      <div style={{ fontWeight: "bold", fontSize: 20 }}>
        {r.id + "." + r.question}
      </div>
      {r.bookmark ? (
        // <FontAwesomeIcon
        //   icon={faBookmark}
        //   size="2x"
        //   color="black"
        //   style={{ alignSelf: "flex-end" }}
        //   onClick={() => bookmarkFun(r.id)}
        // />
        <FaBookmark 
        onClick={() => bookmarkfun(r.id)}/>
      ) : (
        // <FontAwesomeIcon
        //   icon={faBookmarkO}
        //   size="2x"
        //   color="black"
        //   style={{ alignSelf: "flex-end" }}
        //   onClick={() => bookmarkFun(r.id)}
        // />
        
        <FaRegBookmark 
        onClick={() => bookmarkfun(r.id)}
        />
      )}
      <div>
        <div>
        <input
          type="radio"
          id={r.op1}
          name={r.id}
          value={r.op1}
          checked={r.selected === r.op1}
          onChange={(e) => selectanswer(r.id, e.target.value)}
          style={styles.radioButtonItem}
        />
        <label htmlFor={r.op1} style={styles.radioButtonLabel}>
          {r.op1}
        </label>
        </div>
        <div>
        <input
          type="radio"
          id={r.op2}
          name={r.id}
          value={r.op2}
          checked={r.selected === r.op2}
          onChange={(e) => selectanswer(r.id, e.target.value)}
          style={styles.radioButtonItem}
        />
        <label htmlFor={r.op2} style={styles.radioButtonLabel}>
          {r.op2}
        </label>
        </div>
        <div>
        <input
          type="radio"
          id={r.op3}
          name={r.id}
          value={r.op3}
          checked={r.selected === r.op3}
          onChange={(e) => selectanswer(r.id, e.target.value)}
          style={styles.radioButtonItem}
        />
        <label htmlFor={r.op3} style={styles.radioButtonLabel}>
          {r.op3}
        </label>
        </div>
        <div>
        <input
          type="radio"
          id={r.op4}
          name={r.id}
          value={r.op4}
          checked={r.selected === r.op4}
          onChange={(e) => selectanswer(r.id, e.target.value)}
          style={styles.radioButtonItem}
        />
        <label htmlFor={r.op4} style={styles.radioButtonLabel}>
          {r.op4}
        </label>
        </div>
      </div>
    </div>

  );
};

const styles = {
  container: {
 
    paddingLeft: 50,
    paddingRight: 20,
    marginTop: 100,
  },
  radioButtonItem: {
    marginRight: 10,
    marginBottom: 5,
  },
  radioButtonLabel: {
    marginLeft: 5,
  },
};

export default Question;