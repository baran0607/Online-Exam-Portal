

import { useNavigate } from "react-router-dom";
import SideNavbar from "./SideNavbar";
import { useEffect, useState } from "react";
import axios from "axios";


const Home = () => {
    const[exam,setexam]=useState("");
    useEffect(()=>{
        axios.post("http://localhost:8080/getexam",{userid:window.localStorage.getItem("id")}).then((res)=>{
            
            if(res.data.length!==0)
            {
                setexam(res.data)
            }
            })
    },[])
    const nav=useNavigate();
    console.log(exam);
    return ( <>
    <SideNavbar/>
    <h1>welcome {window.localStorage.getItem("name")}</h1>
    {/* <h2>Take test</h2>
    <button onClick={()=>{
        nav("/test")
    }}>Click</button> */}

        
            {exam&&exam!=""?
                <table className="table table-bordered">
            <thead>
            <th>Exam Name</th>
            <th>take Exam</th>
            </thead>
            <tbody>
            
                {exam.map((e)=>
                (<>
                <tr>
                    <td>{e.s.subjectname}</td>
                    <td><button className="btn btn-primary" onClick={()=>{nav("/test",{state:{examid:e.examid}})}}>take test</button></td>
                </tr>
                </>
                ))}
            
            </tbody>
            </table>:<p>You have no test available now</p>

            }
    </> );
}
 
export default Home;