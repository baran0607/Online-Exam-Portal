import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


const Addsubject = () => {
  const nav = useNavigate();
  const [subject, setSubject] = useState({ subjectname: '', allsubtopic: [] });


  // const SubtopicChange = (index, value) => {
  //   setSubject((prevSubject) => {
  //     const updatedSubtopics = [...prevSubject.allsubtopic];
  //     updatedSubtopics[index].subtopicname = value;
  //     return { ...prevSubject, allsubtopic: updatedSubtopics };
  //   });
  // };


  return (<>
    <div>
    <button 
      type="button"
      className="btn btn-outline-primary"
      onClick={()=>{
      nav("/allsubject"); 
       }}
      >Back</button>
    </div>
    <div>
      <h2>Add Subject</h2>
      {/* <label>Subject Name:</label>
      <input
        type="text"
        value={subject.subjectname}
        onChange={(e) =>setSubject ({ ...subject, subjectname: e.target.value })}
      /> */}
      <div class="form-group">
        <label for="name">Subject Name</label>
        <input type="text" class="form-control" id="name"
        value={subject.subjectname} onChange={(e)=>{setSubject({...subject,subjectname:e.target.value})}}/>
      </div>
      {/* <button onClick={AddSubtopic}>Add Subtopic</button> */}
      <button class="btn btn-primary" onClick={()=>{axios.post("http://localhost:8080/addsubject",{subjectname:subject.subjectname}).then((res)=>{
        nav("/addsubtopic",{state:{subject:res.data}})
      })}}>addsubtopics</button>
      {/* {subject.allsubtopic.map((subtopic, index) => (
        <div key={index}>
          <label>{`Subtopic ${index + 1}:`}</label>
          <input
            type="text"
            value={subtopic.name}
            onChange={(e) => SubtopicChange(index, e.target.value)}
          />
        </div>
      ))} */}
      {/* <button onClick={AddSubject}>Add Subject</button> */}
    </div>
    </>);
};

export default Addsubject;



