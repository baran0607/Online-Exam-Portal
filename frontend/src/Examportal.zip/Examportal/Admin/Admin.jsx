import AdminNav from "./AdminNav";

const Admin = () => {
    return ( <>
    <AdminNav/>
    <h1>Welcome {window.localStorage.getItem("name")}</h1>
    </> );
}
 
export default Admin;